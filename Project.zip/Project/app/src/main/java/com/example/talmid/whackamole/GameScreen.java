package com.example.talmid.whackamole;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.Image;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class GameScreen extends AppCompatActivity implements View.OnTouchListener {
    int x=0;
    ImageView im;
    private ConstraintLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_game_screen2);
        SurfaceView surfaceview = (MySurfaceView)findViewById(R.id.surfaceView);
        surfaceview.setZOrderOnTop(true);    // necessary
        SurfaceHolder sfhTrackHolder = surfaceview.getHolder();
        sfhTrackHolder.setFormat(PixelFormat.TRANSPARENT);


          /*

        Intent intent = getIntent();
        Log.d("The place", String.valueOf(x));
        l=(ConstraintLayout)findViewById(R.id.l);

        l.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Log.d("x", String.valueOf(motionEvent.getX()));
                Log.d("x", String.valueOf(motionEvent.getY()));
                return true;
            }
        });
        */
    }



    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        x=view.getScrollX();
        return true;
    }
}
