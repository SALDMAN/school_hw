package com.example.talmid.whackamole;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import java.util.Random;
import java.util.Scanner;


public class MySurfaceView extends SurfaceView implements View.OnTouchListener {

     private SurfaceHolder surfaceHolder;
     private Bitmap bmpIcon;
     private MyThread myThread;
     int [] ArrX= {317,317,855,1411,868};
     int [] ArrY={835,500,500,500,850}; //,1411
     int[] minX={110,110,620,1100,620};
     int[] maxX={540,540,1080,1100,1080};
     int[] minY={5,190,5,5,190};
     int[] maxY={490,830,490,490,830};
     int xPos = 0;
     int yPos = 0;
     int deltaX = 5;
     int deltaY = 5;
     long startVisible;
     boolean visibleChar=true;
     boolean pressOnChar=false;
     long cur;
     int random;
     Random rnd=new Random();
     int points=0;
     int psila=0;
     int iconWidth;
     int iconHeight;
     Intent intent;
     Context context;
     int ClickedX=0;
     int ClickedY=0;

    public MySurfaceView(Context context) {
        super(context);
        init(context);
    }

    public MySurfaceView(Context context, AttributeSet attrs){

        super(context, attrs);
        init(context);
    }

    public MySurfaceView(Context context,AttributeSet attrs, int defStyle) {

        super(context, attrs, defStyle);
        init(context);
    }

    private void init(final Context context){
       this.context = context;
        myThread = new MyThread(this);
        surfaceHolder = getHolder();
        bmpIcon = BitmapFactory.decodeResource(getResources(), R.drawable.bibi);
        iconWidth = bmpIcon.getWidth();
        iconHeight = bmpIcon.getHeight();
        random=rnd.nextInt(5);
        xPos=ArrX[random];
        yPos=ArrY[random];
        xPos -= iconWidth/2;
        yPos -= iconHeight;
        visibleChar=true;
        setOnTouchListener(this);
        surfaceHolder.addCallback(new SurfaceHolder.Callback(){
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                myThread.setRunning(true);
                myThread.start();
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder,  int format, int width, int height) {

                // TODO Auto-generated method stub

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                boolean retry = true;
                myThread.setRunning(false);
                while (retry) {
                    try {
                        myThread.join();
                        retry = false;
                    } catch (InterruptedException e) {
                    }
                }
                // thread is finished
             //   intent = new Intent();
              //  context.startActivity(intent);

            }});
    }

    protected void drawSomething(Canvas canvas) {

        canvas.drawColor(0, android.graphics.PorterDuff.Mode.CLEAR);

            //draw character
         xPos = ArrX[random];
         yPos = ArrY[random];
         xPos -= iconWidth / 2;
         yPos -= iconHeight;

        canvas.drawBitmap(bmpIcon, xPos, yPos, null);

    }

    public void update() {

        if (!visibleChar) {
            // choose char randomally
            random=rnd.nextInt(5);
            visibleChar= true;
            startVisible = System.currentTimeMillis();
        }
        else {
             if (pressOnChar) {
                 points+=5;
                 pressOnChar=false;
                 visibleChar= false;
            }

             cur = System.currentTimeMillis();
             if (cur - startVisible >= 5000) { //
                 visibleChar = false; //
                     //psila++;
                    // if (psila >3) {
                         //exit screen - game ended
                       //  exitGame();
                    // }


             }

        }


    }
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        Log.d("bin","X="+motionEvent.getX()+" Y="+motionEvent.getY());

        //touch a hole
       ClickedX= (int) motionEvent.getX();
       ClickedY=(int) motionEvent.getY();

        if(maxX[random]>=ClickedX&&minX[random]<=ClickedX&&maxY[random]>= ClickedY&&minY[random]<=ClickedY)
            pressOnChar=true;
        return false;
    }
   // void exitGame() {
     //   myThread.setRunning(false);
   // }
}
