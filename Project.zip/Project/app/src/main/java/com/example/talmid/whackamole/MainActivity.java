package com.example.talmid.whackamole;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RelativeLayout rlId = (RelativeLayout)findViewById(R.id.rlId);
        rlId.setOnTouchListener(this);




    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {

        Intent intent = new Intent(this,GameScreen.class);
        startActivity(intent);

        return true;
    }
}
